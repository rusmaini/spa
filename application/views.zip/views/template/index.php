
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>UPAdev Starter Kit</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="stylesheet" href="<?=base_url()?>bootstrap/css/bootstrap.css" media="screen">
    <link rel="stylesheet" href="<?=base_url()?>bootstrap/css/bootswatch.min.css">
    <!-- guna themes -->
    <link rel="stylesheet" href="<?=base_url()?>themes/journal/css/bootstrap.css" media="screen">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="../bower_components/html5shiv/dist/html5shiv.js"></script>
      <script src="../bower_components/respond/dest/respond.min.js"></script>
    <![endif]-->
 
  </head>
  <body>
  	<!-- Nav Bar - Header -->
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<?=anchor('','Sistem',array('class'=>'navbar-brand'))?>				
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
			</div>
			
			<div class="navbar-collapse collapse" id="navbar-main">
				<!-- Menu Left - Main Menu -->
				<ul class="nav navbar-nav">
					<li>
						<?=anchor('home/about','About')?>
					</li>
					<li>
						<?=anchor('home/help','Help')?>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes">Menu Dropdown <span class="caret"></span></a>
						<ul class="dropdown-menu" aria-labelledby="themes">
							<li><a href="#">Default</a></li>
							<li class="divider"></li>
							<li><a href="#">Sub Menu 1</a></li>
							<li><a href="#">Sub Menu 2</a></li>
						</ul>
					</li>
				</ul>
				
				<!-- Menu Right -->
				<ul class="nav navbar-nav navbar-right">
					<li><?= (!$this->ion_auth->logged_in())? anchor('auth/login','Log Masuk'):anchor('auth/logout','Log Keluar')?></li>
					<li><?= anchor('auth/','Auth')?></li>
				</ul>
			</div>
		</div>
	</div>

	<div class="container">
		<!-- Header -->
		<!--
		<div class="page-header" id="banner">
			<div class="row">
				<div class="col-lg-8 col-md-7 col-sm-6">
					<h1>UPAdev Starter Kit</h1>
					<p class="lead">It's not a bug, it's a feature..</p>
				</div>
				<div class="col-lg-4 col-md-5 col-sm-6">
					<div class="sponsor">
						<a href="#" target="_blank">
						<img src="<?=base_url()?>assets/img/dadu.jpg" alt="Shopify">
						</a>
					</div>
				</div>
			</div>
		</div>
		-->
		<!-- Main Content -->
		<?php $this->load->view($content) ?>
		
	  	<!-- Footer -->
		<footer>
			<div class="row">
				<div class="col-lg-12">
					<p>Disediakan oleh <a href="http://rusmaini.com" rel="nofollow">Rusmaini Miftah</a>.</p>
					<p>Gabungan <a href="http://www.codeigniter.com/" rel="nofollow">CodeIgniter 3</a> dan <a href="http://getbootstrap.com" rel="nofollow">Bootstrap 3</a>.</p>
				</div>
			</div>
		</footer>
	</div>

    <script src="<?=base_url()?>assets/js/jquery.min.js"></script>
    <script src="<?=base_url()?>bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
